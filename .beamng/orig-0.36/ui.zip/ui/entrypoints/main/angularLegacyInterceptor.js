// abandon all hope ye who enter here
(function () {
  const module = angular.module("material.components.tabs");

  let originalDirectiveFn;
  for (let i = module._invokeQueue.length - 1; i >= 0; i--) {
    const invokeArgs = module._invokeQueue[i];
    if (invokeArgs[1] === "directive" && invokeArgs[2][0] === "mdTemplate") {
      // console.log("found mdTemplate directive, modifying...");
      originalDirectiveFn = invokeArgs[2][1];
      module._invokeQueue.splice(i, 1);
      break;
    }
  }
  if (!originalDirectiveFn) {
    console.error("Failed to find mdTemplate directive. Expect deprecation warnings in console when mdTabs in use.");
    return;
  }

  function supressDeprecationWarning(element) {
    if (!element) return;
    if (!element.__addEventListener) element.__addEventListener = element.addEventListener;
    element.addEventListener = function (type, listener, options) {
      if (type === "DOMSubtreeModified") {
        // console.warn("hijacking DOMSubtreeModified", element);
        element.__subtreeListener = listener;
        return;
      }
      return element.__addEventListener.apply(this, arguments);
    };
  }

  module.directive("mdTemplate", ["$compile", "$mdUtil", function ($compile, $mdUtil) {
    const directive = originalDirectiveFn($compile, $mdUtil);
    const originalLink = directive.link;
    directive.link = function (scope, element, attr, ctrl) {
      // console.log("overriding mdTemplate on", element);
      setTimeout(() => {
        setupSubtreeEmulator(element[0]);
      }, 0);
      supressDeprecationWarning(element[0]);
      return originalLink.apply(this, arguments);
    };
    return directive;
  }]);

  function setupSubtreeEmulator(targetNode) {
    const observer = new MutationObserver(mutations => {
      const now = Date.now();
      mutations.forEach(mutation => {
        if (mutation.target.__subtreeListener) {
          const evt = {
            type: "DOMSubtreeModified",
            target: mutation.target,
            bubbles: true,
            cancelable: false,
            timeStamp: now,
            attrName: mutation.attributeName || null,
            prevValue: mutation.oldValue || null,
            newValue: mutation.target.nodeValue || null,
            relatedNode: mutation.addedNodes.length
                ? mutation.addedNodes[0]
                : mutation.removedNodes.length
                ? mutation.removedNodes[0]
                : null,
            stopPropagation: () => {},
            preventDefault: () => {},
            stopImmediatePropagation: () => {},
          };
          mutation.target.__subtreeListener(evt);
        }
      });
    });
    observer.observe(targetNode, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true,
      attributeOldValue: true,
      characterDataOldValue: true,
    });
  }
})();
