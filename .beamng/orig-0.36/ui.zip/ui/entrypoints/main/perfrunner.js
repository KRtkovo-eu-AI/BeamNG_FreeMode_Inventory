// perfRunner.js (ES module)
//
// What this does (KISS):
// - Collects URLs from the current page (scripts, stylesheets, images).
// - Measures via Fetch and XHR, each once cold and once warm. No per-URL fallback.
// - Prints a one-time legend, a short overall summary, and per-transport summaries.
// - Always explains metrics in plain terms.
//
// How to use:
// - Import and call `testVfsPerformance()` from your code or DevTools module context.
//
// Notes:
// - If Fetch is unavailable or fails, XHR still runs so you always get results.
// - p50 means the median (half of requests are faster, half slower). KiB/s is kibibytes per second.
// No hardcoded URLs; sources come from the page.

const now = () => performance.now();
let warnedNoFetch = false;
let printedLegend = false;

/**
 * Returns a de-duplicated list of resource URLs discovered on the page.
 */
function collectResourceUrls() {
  const set = new Set();
  const add = (u) => { if (u) set.add(u); };
  document.querySelectorAll('script[src]').forEach(el => add(el.src || el.getAttribute('src')));
  document.querySelectorAll('link[rel="stylesheet"][href]').forEach(el => add(el.href || el.getAttribute('href')));
  document.querySelectorAll('img[src]').forEach(el => add(el.src || el.getAttribute('src')));
  return Array.from(set);
}

/**
 * Measures a single URL using Fetch streaming to capture TTFB and throughput.
 * cacheMode: 'reload' for cold, 'default' for warm.
 * Returns null on failure.
 */
async function measureViaFetch(url, fetchImpl, nowImpl, cacheMode = 'reload') {
  const started = nowImpl();
  let ttfbMs = NaN, bytes = 0;
  const res = await fetchImpl(url, { cache: cacheMode }).catch(() => null);
  if (!res || !res.ok || !res.body) return null;

  const r = res.body.getReader();
  let first = true;
  let chunkCount = 0;
  for (;;) {
    const t = nowImpl();
    const { done, value } = await r.read();
    if (done) break;
    if (first) { ttfbMs = t - started; first = false; }
    bytes += value.byteLength;
    chunkCount++;
  }
  const totalMs = nowImpl() - started;
  const kibps = totalMs > 0 ? (bytes / 1024) / (totalMs / 1000) : NaN;
  const downloadMs = Number.isFinite(ttfbMs) ? Math.max(0, totalMs - ttfbMs) : NaN;
  const contentLengthHeader = Number.parseInt(res.headers.get('content-length') || '', 10);
  const contentType = res.headers.get('content-type') || '';
  const status = res.status;
  return { ttfbMs, totalMs, downloadMs, kibps, bytes, chunkCount, status, contentType, contentLengthHeader };
}

/**
 * Measures a single URL using XHR, capturing TTFB via first progress event.
 */
function measureViaXHR(url, nowImpl) {
  return new Promise((resolve) => {
    const xhr = new XMLHttpRequest();
    const started = nowImpl();
    let ttfbMs = NaN;
    let chunkCount = 0;
    xhr.responseType = 'arraybuffer';
    xhr.addEventListener('progress', () => {
      if (!Number.isFinite(ttfbMs)) ttfbMs = nowImpl() - started;
      chunkCount++;
    });
    xhr.onload = () => {
      const totalMs = nowImpl() - started;
      const arrayBuffer = xhr.response;
      const bytes = arrayBuffer && arrayBuffer.byteLength ? arrayBuffer.byteLength : 0;
      const downloadMs = Number.isFinite(ttfbMs) ? Math.max(0, totalMs - ttfbMs) : NaN;
      const contentLengthHeader = Number.parseInt(xhr.getResponseHeader('content-length') || '', 10);
      const contentType = xhr.getResponseHeader('content-type') || '';
      const status = xhr.status || 200; // local:// may report 0
      const kibps = totalMs > 0 ? (bytes / 1024) / (totalMs / 1000) : NaN;
      resolve({ ttfbMs, totalMs, downloadMs, kibps, bytes, chunkCount, status, contentType, contentLengthHeader });
    };
    xhr.onerror = xhr.ontimeout = () => resolve(null);
    try {
      xhr.open('GET', url, true);
      xhr.send();
    } catch (e) {
      resolve(null);
    }
  });
}

async function runPerf() {
  const list = collectResourceUrls();
  const nowImpl = now;
  const resolvedFetch = (typeof fetch !== 'undefined' ? fetch : null);

  if (!resolvedFetch && !warnedNoFetch) {
    console.warn('[perf] fetch is not available; falling back to XHR only.');
    warnedNoFetch = true;
  }

  const addCacheBust = (u, tag) => {
    try {
      const url = new URL(u, location.href);
      url.searchParams.set(tag, Date.now().toString());
      return url.toString();
    } catch (e) {
      // Fallback for non-standard schemes
      const sep = u.includes('?') ? '&' : '?';
      return `${u}${sep}${tag}=${Date.now()}`;
    }
  };

  const coldUrls = list.map(u => addCacheBust(u, 'perf_cold'));
  const warmUrls = list.slice();

  async function forEachLimit(items, limit, fn) {
    const q = items.slice();
    const workers = Array(Math.min(limit, q.length)).fill(0).map(async () => {
      while (q.length) {
        const it = q.shift();
        try { await fn(it); } catch (e) {}
      }
    });
    await Promise.all(workers);
  }
  const CONCURRENCY = 7;

  // Fetch: cold, prewarm, warm
  const resultsFetchCold = [];
  const resultsFetchWarm = [];
  if (resolvedFetch) {
    await forEachLimit(coldUrls, CONCURRENCY, async (u) => {
      const r = await measureViaFetch(u, resolvedFetch, nowImpl, 'reload').catch(() => null);
      if (r) resultsFetchCold.push(r);
    });
    // Prewarm cache for warm pass
    await forEachLimit(warmUrls, CONCURRENCY, async (u) => {
      await measureViaFetch(u, resolvedFetch, nowImpl, 'default').catch(() => null);
    });
    await forEachLimit(warmUrls, CONCURRENCY, async (u) => {
      const r = await measureViaFetch(u, resolvedFetch, nowImpl, 'default').catch(() => null);
      if (r) resultsFetchWarm.push(r);
    });
  }

  // XHR: cold, prewarm, warm
  const resultsXHRCold = [];
  const resultsXHRWarm = [];
  await forEachLimit(coldUrls, CONCURRENCY, async (u) => {
    const r = await measureViaXHR(u, nowImpl).catch?.(() => null);
    if (r) resultsXHRCold.push(r);
  });
  // Prewarm for warm pass
  await forEachLimit(warmUrls, CONCURRENCY, async (u) => {
    await measureViaXHR(u, nowImpl).catch?.(() => null);
  });
  await forEachLimit(warmUrls, CONCURRENCY, async (u) => {
    const r = await measureViaXHR(u, nowImpl).catch?.(() => null);
    if (r) resultsXHRWarm.push(r);
  });

  const summaryFetchCold = computeSummary(resultsFetchCold);
  const summaryFetchWarm = computeSummary(resultsFetchWarm);
  const summaryXHRCold = computeSummary(resultsXHRCold);
  const summaryXHRWarm = computeSummary(resultsXHRWarm);

  // Choose a primary summary for quick glance (prefer warm Fetch, then warm XHR)
  const summary = summaryFetchWarm.count ? summaryFetchWarm : (summaryXHRWarm.count ? summaryXHRWarm : (summaryFetchCold.count ? summaryFetchCold : summaryXHRCold));

  return {
    summary,
    resultsFetchCold,
    resultsFetchWarm,
    resultsXHRCold,
    resultsXHRWarm,
    summaryFetchCold,
    summaryFetchWarm,
    summaryXHRCold,
    summaryXHRWarm,
  };
}

function computeSummary(results) {
  const n = results.length;
  const sum = (f) => results.reduce((a, r) => a + f(r), 0);
  const avg = (f) => n ? (sum(f) / n) : NaN;
  const all = (f) => results.map(f).filter((v) => Number.isFinite(v));
  const min = (f) => {
    const arr = all(f);
    return arr.length ? Math.min(...arr) : NaN;
  };
  const max = (f) => {
    const arr = all(f);
    return arr.length ? Math.max(...arr) : NaN;
  };
  const median = (f) => {
    const arr = all(f).sort((a, b) => a - b);
    if (!arr.length) return NaN;
    const m = Math.floor(arr.length / 2);
    return arr.length % 2 ? arr[m] : (arr[m - 1] + arr[m]) / 2;
  };

  return {
    count: n,
    avgTtfbMs: avg(r => r.ttfbMs),
    p50TtfbMs: median(r => r.ttfbMs),
    minTtfbMs: min(r => r.ttfbMs),
    maxTtfbMs: max(r => r.ttfbMs),
    avgTotalMs: avg(r => r.totalMs),
    p50TotalMs: median(r => r.totalMs),
    minTotalMs: min(r => r.totalMs),
    maxTotalMs: max(r => r.totalMs),
    avgDownloadMs: avg(r => r.downloadMs),
    avgKibps: avg(r => r.kibps),
    totalBytes: sum(r => r.bytes),
    avgChunkCount: avg(r => r.chunkCount),
  };
}

function formatPerfSummary(summary) {
  const to3 = (v) => Number.isFinite(v) ? v.toFixed(3) : 'NaN';
  const to1 = (v) => Number.isFinite(v) ? v.toFixed(1) : 'NaN';
  const to2 = (v) => Number.isFinite(v) ? v.toFixed(2) : 'NaN';
  const lines = [];
  lines.push('Performance summary');
  lines.push(`- count: ${summary.count} — successful responses measured`);
  lines.push(`- avg_ttfb_ms: ${to3(summary.avgTtfbMs)} — average time until the server starts replying`);
  lines.push(`- p50_ttfb_ms: ${to3(summary.p50TtfbMs)} — median time to first byte (half faster, half slower)`);
  lines.push(`- min_ttfb_ms: ${to3(summary.minTtfbMs)}, max_ttfb_ms: ${to3(summary.maxTtfbMs)}`);
  lines.push(`- avg_total_ms: ${to3(summary.avgTotalMs)} — average time from starting the request to the last byte`);
  lines.push(`- p50_total_ms: ${to3(summary.p50TotalMs)} — median total load time`);
  lines.push(`- min_total_ms: ${to3(summary.minTotalMs)}, max_total_ms: ${to3(summary.maxTotalMs)}`);
  lines.push(`- avg_download_ms: ${to3(summary.avgDownloadMs)} — average time spent downloading after the first byte arrives`);
  lines.push(`- avg_kibps: ${to1(summary.avgKibps)} — average download speed (KiB/s)`);
  lines.push(`- total_bytes: ${summary.totalBytes} — total bytes received across requests`);
  lines.push(`- avg_chunks: ${to3(summary.avgChunkCount)} — average number of data chunks per response`);
  return lines.join('\n');
}

function formatComparisonTable(fetchCold, fetchWarm, xhrCold, xhrWarm, missingText = '-') {
  const cols = [
    { name: 'Metric' },
    { name: 'Fetch(cold)' },
    { name: 'Fetch(warm)' },
    { name: 'XHR(cold)' },
    { name: 'XHR(warm)' },
  ];
  const rows = [];
  const to3 = (v) => Number.isFinite(v) ? v.toFixed(3) : 'NaN';
  const to1 = (v) => Number.isFinite(v) ? v.toFixed(1) : 'NaN';
  const formatKiBpsHuman = (kibps) => {
    if (!Number.isFinite(kibps)) return 'NaN';
    // Always show as MiB/s with 2 decimals for consistent width
    return `${(kibps / 1024).toFixed(2)} MiB/s`;
  };
  const formatBytesHuman = (bytes) => {
    if (!Number.isFinite(bytes)) return 'NaN';
    // Always show as MiB with 2 decimals for consistent width
    return `${(bytes / (1024 * 1024)).toFixed(2)} MiB`;
  };
  const v = (s, f, fmt = to3) => s && s.count ? fmt(f(s)) : missingText;
  const add = (label, getter, fmt) => {
    rows.push([
      label,
      v(fetchCold, getter, fmt),
      v(fetchWarm, getter, fmt),
      v(xhrCold, getter, fmt),
      v(xhrWarm, getter, fmt),
    ]);
  };
  add('count', s => s.count, (x) => String(x));
  add('avg_ttfb_ms', s => s.avgTtfbMs, to3);
  add('p50_ttfb_ms', s => s.p50TtfbMs, to3);
  add('min_ttfb_ms', s => s.minTtfbMs, to3);
  add('max_ttfb_ms', s => s.maxTtfbMs, to3);
  add('avg_total_ms', s => s.avgTotalMs, to3);
  add('p50_total_ms', s => s.p50TotalMs, to3);
  add('min_total_ms', s => s.minTotalMs, to3);
  add('max_total_ms', s => s.maxTotalMs, to3);
  add('avg_download_ms', s => s.avgDownloadMs, to3);
  add('avg_speed', s => s.avgKibps, formatKiBpsHuman);
  add('total_bytes', s => s.totalBytes, formatBytesHuman);
  add('avg_chunks', s => s.avgChunkCount, to3);
  // Ensure consistent minimum widths for certain metrics so 100+ ms values fit nicely
  const minMsWidth = 7; // e.g., "123.456"
  const minSpeedWidth = 12; // e.g., "123.45 MiB/s"
  const minBytesWidth = 10; // e.g., "1234.56 MiB"
  for (let i = 0; i < rows.length; i++) {
    const label = rows[i][0];
    if (label.endsWith('_ms')) {
      for (let c = 1; c < rows[i].length; c++) {
        const s = String(rows[i][c]);
        if (!/[0-9]/.test(s)) continue; // don't pad non-numerics like 'n/a'
        rows[i][c] = s.padStart(minMsWidth, ' ');
      }
    } else if (label === 'avg_speed') {
      for (let c = 1; c < rows[i].length; c++) {
        const s = String(rows[i][c]);
        if (!/[0-9]/.test(s)) continue;
        rows[i][c] = s.padStart(minSpeedWidth, ' ');
      }
    } else if (label === 'total_bytes') {
      for (let c = 1; c < rows[i].length; c++) {
        const s = String(rows[i][c]);
        if (!/[0-9]/.test(s)) continue;
        rows[i][c] = s.padStart(minBytesWidth, ' ');
      }
    }
  }

  // Align decimal points per column for decimal-based rows
  const isDecimalRow = (label) => label.endsWith('_ms') || label === 'avg_speed' || label === 'total_bytes' || label === 'avg_chunks';
  for (let col = 1; col <= 4; col++) {
    let maxDot = 0;
    for (let r = 0; r < rows.length; r++) {
      const label = rows[r][0];
      if (!isDecimalRow(label)) continue;
      const s = String(rows[r][col]);
      if (!/[0-9]/.test(s)) continue; // skip non-numerics like 'n/a'
      const idx = s.indexOf('.');
      if (idx >= 0) maxDot = Math.max(maxDot, idx);
    }
    if (maxDot === 0) continue;
    for (let r = 0; r < rows.length; r++) {
      const label = rows[r][0];
      if (!isDecimalRow(label)) continue;
      const s = String(rows[r][col]);
      if (!/[0-9]/.test(s)) continue; // skip 'n/a'
      const idx = s.indexOf('.');
      if (idx >= 0 && idx < maxDot) {
        rows[r][col] = ' '.repeat(maxDot - idx) + s;
      }
    }
  }

  const table = [cols.map(c => c.name), ...rows];
  const widths = table[0].map((_, i) => Math.max(...table.map(r => String(r[i]).length)));
  const pad = (str, n) => String(str).padEnd(n, ' ');

  const hr = '+' + widths.map(w => '-'.repeat(w + 2)).join('+') + '+\n';
  let out = '';
  out += hr;
  out += '|' + table[0].map((c, i) => ' ' + pad(c, widths[i]) + ' ').join('|') + '|\n';
  out += hr;
  for (let r = 1; r < table.length; r++) {
    out += '|' + table[r].map((c, i) => ' ' + pad(c, widths[i]) + ' ').join('|') + '|\n';
  }
  out += hr;
  return out;
}

function formatABTable(label, a, b) {
  const to3 = (v) => Number.isFinite(v) ? v.toFixed(3) : 'NaN';
  const to2 = (v) => Number.isFinite(v) ? v.toFixed(2) : 'NaN';
  const improvement = (av, bv, higherIsBetter) => {
    if (!Number.isFinite(av) || !Number.isFinite(bv) || av === 0) return '—';
    const frac = higherIsBetter ? ((bv - av) / av) : ((av - bv) / av);
    const d = frac * 100;
    const s = d >= 0 ? '+' : '';
    let factor = NaN;
    if (higherIsBetter) {
      factor = av > 0 ? (bv / av) : NaN;
    } else {
      factor = bv > 0 ? (av / bv) : NaN;
    }
    let factorText = '—';
    if (Number.isFinite(factor) && factor > 0) {
      if (factor >= 1) factorText = `${to2(factor)}× faster`;
      else factorText = `${to2(1 / factor)}× slower`;
    }
    return `${s}${to2(d)}% (${factorText})`;
  };
  const rows = [];
  rows.push(['count', String(a?.count || 0), String(b?.count || 0), '']);
  rows.push(['avg_ttfb_ms', to3(a?.avgTtfbMs), to3(b?.avgTtfbMs), improvement(a?.avgTtfbMs, b?.avgTtfbMs, false)]);
  rows.push(['p50_ttfb_ms', to3(a?.p50TtfbMs), to3(b?.p50TtfbMs), improvement(a?.p50TtfbMs, b?.p50TtfbMs, false)]);
  rows.push(['avg_total_ms', to3(a?.avgTotalMs), to3(b?.avgTotalMs), improvement(a?.avgTotalMs, b?.avgTotalMs, false)]);
  rows.push(['p50_total_ms', to3(a?.p50TotalMs), to3(b?.p50TotalMs), improvement(a?.p50TotalMs, b?.p50TotalMs, false)]);
  rows.push(['avg_speed (MiB/s)', Number.isFinite(a?.avgKibps) ? (a.avgKibps/1024).toFixed(2) : 'NaN', Number.isFinite(b?.avgKibps) ? (b.avgKibps/1024).toFixed(2) : 'NaN', improvement(a?.avgKibps, b?.avgKibps, true)]);

  const head = ['Metric', `${label} v1`, `${label} v2`, 'Improvement (v2 vs v1)'];
  const table = [head, ...rows];
  const widths = table[0].map((_, i) => Math.max(...table.map(r => String(r[i]).length)));
  const pad = (str, n) => String(str).padEnd(n, ' ');
  const hr = '+' + widths.map(w => '-'.repeat(w + 2)).join('+') + '+\n';
  let out = '';
  out += hr;
  out += '|' + table[0].map((c, i) => ' ' + pad(c, widths[i]) + ' ').join('|') + '|\n';
  out += hr;
  for (let r = 1; r < table.length; r++) {
    out += '|' + table[r].map((c, i) => ' ' + pad(c, widths[i]) + ' ').join('|') + '|\n';
  }
  out += hr;
  return out;
}

// No globals are exposed; functions are exported for explicit import only.

export function testVfsPerformance() {
  console.log('==============================================================');
  console.log(' How to run the test properly:');
  console.log('  - go to vehicles > display options > expand configs = always.');
  console.log('  - slowly scroll to the bottom of the page and run the testVfsPerformance() function in the console.');
  console.log('==============================================================');
  console.log('Starting VFS performance test - this may take a few seconds ...');
  const setScheme = (v) => new Promise((resolve) => {
    if (typeof bngApi !== 'undefined' && bngApi.engineLua) {
      bngApi.engineLua(`Engine.UI.setLocalSchemeVersion(${bngApi.serializeToLua(v)})`, () => resolve());
    } else {
      console.warn('[perf] bngApi.engineLua not available; skipping scheme switch');
      resolve();
    }
  });

  (async () => {
    try {
      await setScheme('v1');
      const resV1 = await runPerf();
      await setScheme('v2');
      const resV2 = await runPerf();
      const { summaryFetchCold: f1c, summaryFetchWarm: f1w, summaryXHRCold: x1c, summaryXHRWarm: x1w } = resV1;
      const { summaryFetchCold: f2c, summaryFetchWarm: f2w, summaryXHRCold: x2c, summaryXHRWarm: x2w } = resV2;
      if (!printedLegend) {
        console.log(
          'Legend\n' +
          '- p50: median (50th percentile)\n' +
          '- ttfb: time to first byte\n' +
          '- ms: milliseconds\n' +
          '- KiB/s: kibibytes per second\n' +
          '- total_ms: time from request start to last byte\n' +
          '- download_ms: time after first byte until finish\n' +
          '- chunks: number of data chunks in the response'
        );
        printedLegend = true;
      }
      // Assume Fetch not working on v1: show N/A for Fetch columns
      console.log('\n=== v1 (Fetch/XHR cold/warm) ===\n' + formatComparisonTable(null, null, x1c, x1w, 'n/a'));
      console.log('\n=== v2 (Fetch/XHR cold/warm) ===\n' + formatComparisonTable(f2c, f2w, x2c, x2w));
      console.log('\n=== v1 vs v2 (XHR warm) ===\n' + formatABTable('XHR warm', x1w, x2w));
    } catch (e) {
      console.error('[perf] Error during perf runs:', e);
    } finally {
      // Ensure final scheme is v2
      await setScheme('v2');
    }
  })();
}

if (typeof window !== 'undefined') {
  window.testVfsPerformance = testVfsPerformance;
}