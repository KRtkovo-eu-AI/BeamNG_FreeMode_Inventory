'use strict'

angular.module('beamng.stuff')

.controller('CareerVehicleSelectController', ['$rootScope', '$scope', 'toastr', '$state', 'Settings', '$http', '$filter', 'Utils', 'gamepadNav', '$stateParams', 'ConfirmationDialog', 'translateService', 'MessageToasterService', function($rootScope, $scope, toastr, $state, Settings, $http, $filter, Utils, gamepadNav, $stateParams, ConfirmationDialog, translateService, messageToasterService) {

  $scope.data = $stateParams.data
  $scope.$on('$destroy', function() {
    bngApi.engineLua("simTimeAuthority.popPauseRequest()");
  })

  $scope.click = function(cmd) {
    bngApi.engineLua(cmd)
    $scope.$parent.app.stickyPlayState = null
    $state.go('play');
  }

}])
