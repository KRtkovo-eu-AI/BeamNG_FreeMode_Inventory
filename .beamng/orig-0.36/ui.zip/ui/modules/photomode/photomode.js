angular.module('beamng.stuff')

.value('showPhotomodeGrid', {
  show:false
})

.value('photomodeExtraFeatures', {
  enabled: false,
  expanded: false
})

.value('photomodeSavedCamera', {
  data: null
})

.value('photomodeSavedSettings', {
  data: null
})

.controller('PhotoModeController', ['$scope', 'Utils', 'showPhotomodeGrid', 'photomodeExtraFeatures', 'photomodeSavedCamera', 'photomodeSavedSettings', 'Environment', '$translate', function($scope, Utils, showPhotomodeGrid, photomodeExtraFeatures, photomodeSavedCamera, photomodeSavedSettings, Environment, $translate)  {

  //console.debug('Entering photomode')
  bngApi.engineLua("photoModeOpen = true"); // yes, this is horrible
  bngApi.engineLua("if core_camera.getActiveCamName() ~= 'path' then commands.setFreeCamera() end")
  bngApi.engineLua("MoveManager.rollRelative = 0; core_camera.savedCameraFov = core_camera.getFovDeg()")
  bngApi.engineLua('Engine.NodeGrabber_setFixedNodesVisible(false)')
 // bngApi.engineLua('campaign_exploration.activemode()')
  // disable pillars autohide if in garage mode
  bngApi.engineLua("if gameplay_garageMode and gameplay_garageMode.isActive() then gameplay_garageMode.setObjectsAutohide(false) end");

  var vm = this

  vm.environment = Environment
  Environment.update()

  window.bridge.uiNavEvents.setFilteredEvents('focus_lr')

  $scope.$on('SettingsChanged', function (event, data) {
    vm.dynReflectionEnabled = data.values.GraphicDynReflectionEnabled
    vm.PostFXDOFGeneralEnabled = data.values.PostFXDOFGeneralEnabled
    vm.PostFXSSAOGeneralEnabled = data.values.PostFXSSAOGeneralEnabled
    vm.cameraFreeSmoothMovement = data.values.cameraFreeSmoothMovement
  })

    $scope.$on('replayStateChanged', function (event, val) {
      $scope.$evalAsync(function () {
        vm.loadedFile = val.loadedFile;
        vm.speed = val.speed;
      });
    });

  vm.toggleDynReflection = function () {
    var changeObj = {GraphicDynReflectionEnabled: vm.dynReflectionEnabled}
    bngApi.engineLua(`settings.setState( ${bngApi.serializeToLua(changeObj)} )`)
  }

  vm.toggleDOFPostFX = function () {
    var changeObj = {PostFXDOFGeneralEnabled: vm.PostFXDOFGeneralEnabled}
    bngApi.engineLua(`settings.setState( ${bngApi.serializeToLua(changeObj)} )`)
  }

  vm.toggleSSAOPostFX = function () {
    var changeObj = {PostFXSSAOGeneralEnabled: vm.PostFXSSAOGeneralEnabled}
    bngApi.engineLua(`settings.setState( ${bngApi.serializeToLua(changeObj)} )`)
  }

  vm.toggleCameraFreeSmoothMovement = function () {
    var changeObj = {cameraFreeSmoothMovement: vm.cameraFreeSmoothMovement}
    bngApi.engineLua(`settings.setState( ${bngApi.serializeToLua(changeObj)} )`)
  }

 // bngApi.engineLua('campaign_exploration.activephotomission()')
  bngApi.engineLua('settings.notifyUI()')
  bngApi.engineLua('Steam.isWorking', function (steamStatus) {
    $scope.$evalAsync(function () {
      vm.steamAvailable = steamStatus
    })
  })
  bngApi.engineLua('campaign_exploration and campaign_photoSafari.photomodeOpen',function(isCampaign){
    $scope.$evalAsync(function () {
      vm.campaingexp = isCampaign
    })
   })
  bngApi.engineLua('scenario_scenarios and scenario_scenarios.getScenario()', function(data) {
    $scope.$evalAsync(function () {
      vm.currentScenario = data
    })
  })

  vm.settings = {
    fov: 60,
    roll: 0,
    speed: 15,
    visible: true,
    showGrid: showPhotomodeGrid.show,
    colorCorrectionStrength: 1,

    // Bloom
    bloomThreshold: 3.5,

    // DoF
    autofocus: false,
    dofAutofocus: false,      // Initialize DOF autofocus as disabled by default
    dofMaxBlurNear: 0,      // Start with no near blur
    dofMaxBlurFar: 0.15,    // Slight far blur by default
    dofFocusRange: 50,      // Mid-range focus
    dofAperture: 8,         // f/8 for balanced depth of field
    dofFalloffSharpness: 1, // Default value for Falloff Sharpness

    // SSAO
    SSAOContrast: 2,
    SSAORadius: 1.5,
    SSAOQuality: 1,

    // Rendering
    // Shadows
    shadowSize: 10,
    shadowDistance: 1600,
    logWeight: 0.98,

    // LOD
    detailAdjust: 1.5,
    lodScale: 0.75,
    GroundCoverScale: 1,

  }

  // Get PostFX values
  var mapKeyToSettings= [
    // ["PostEffectCombinePassObject.colorCorrectionRampPath","colorCorrectionStrength"],
    ["$DOFPostFx::BlurMax","dofMaxBlurFar"],
    ["$DOFPostFx::BlurMin","dofMaxBlurNear"],
    ["$DOFPostFx::FocusRangeMax","dofFocusRange"],
    ["$DOFPostFx::BlurCurveFar","dofAperture"],
    ["$DOFPostFx::FocusRangeMin","dofFalloffSharpness"],
    // ["$SSAOPostFx::overallStrength","SSAOContrast"],
    ["$PostFXManager::PostFX::EnableDOF","dofEnabled"],
    ["$PostFXManager::PostFX::EnableSSAO","ssaoEnabled"],
  ]
  bngApi.engineLua('require("util/renderComponentsAPI").getCurrentSettings()',
    (data) => {
      $scope.$evalAsync(() => {
        vm.originalPostSettings = {}
        for(var i = 0; i<mapKeyToSettings.length; i++) {
          vm.settings[mapKeyToSettings[i][1]] = Number(data[mapKeyToSettings[i][0]])
          vm.originalPostSettings[mapKeyToSettings[i][0]] = data[mapKeyToSettings[i][0]]
        }
        vm.enableWatchers()
      })
    }
  )

  // quick fix for reseting the values on enter, but actually that should be doable just by setting the default values after the watchers, so setting them would trigger the watchers...
  bngApi.engineLua( 'core_camera.setFOV(0, ' + vm.settings.fov + ');' )
  bngApi.engineLua( 'core_camera.rollAbs(' + vm.settings.roll + ')' )
  bngApi.engineLua( 'core_camera.setSpeed(' + vm.settings.speed + ')' )
  vm.settings.cameraSpeed = vm.settings.speed

  vm.showSettings   = true
  vm.advancedSettings = false
  vm.showControls = true
  vm.storedTime = 0
  vm.PostFXSSAOGeneralQuality = "Low"

  vm.takePic = function() {
    vm.doScreenshot()
  }

  vm.takeBigPic = function() {
    vm.doBigScreenShot()
  }

  vm.takeHugePic = function() {
    vm.doHugeScreenShot()
  }

  vm.doMotionBlurScreenShot = function() {
    timedCall(next => {
      // First unpause physics
      bngApi.engineLua('simTimeAuthority.togglePause()', () => {
        // Wait 100ms for motion to start
        setTimeout(() => {
          // Take the screenshot
          bngApi.engineLua('require("screenshot").takeBigScreenShot()', () => {
            // Wait another 100ms to ensure screenshot is taken
            setTimeout(() => {
              // Pause physics again
              bngApi.engineLua('simTimeAuthority.togglePause()', next)
            }, 100)
          })
        }, 100)
      })
    })
  }

  function uiEnabled(enable, ts=false, callback=null) {
    enable = !!enable;
    bngApi.engineLua(`extensions.ui_visibility.set(${enable})`, () => {
      function next() {
        Utils.waitForCefAndAngular(() => {
          vm.showControls = enable;
          if (enable)
            $scope.$apply();
          if (callback) {
            Utils.waitForCefAndAngular(() => {
              callback();
            });
          }
        });
      }
      const cursor = enable ? "showCursor" : "hideCursor";
      if (ts)
        bngApi.engineScript(`${cursor}();`, next);
      else
        next();
    });
  }

  // async would be nicer
  function timedCall(call, ts=false) {
    uiEnabled(false, ts, () => {
      call(() => {
        Utils.waitForCefAndAngular(() => {
          uiEnabled(true, ts);
        });
      });
    });
  }

  /// afaik photo-safari mode was deprecated long time ago
  // vm.doScreenshot = function() {
  //   timedCall(next => {
  //     let countNext = 0;
  //     function callNext() {
  //       countNext--;
  //       if (countNext <= 0)
  //         next();
  //     }
  //     if (vm.campaingexp) {
  //       countNext++;
  //       bngApi.engineLua('campaign_photoSafari.takepiccheck()', (val) => {
  //         vm.objContained = val
  //         if(vm.objContained){
  //           console.log("horrieh")
  //         }
  //         else{
  //           console.log("wrong objContained")
  //          // break
  //         }
  //         callNext();
  //       })
  //     }
  //     if (vm.currentScenario && vm.currentScenario.scenarioName == 'bussafari') {
  //       countNext++;
  //       bngApi.engineLua('scenario_scenarios.takephoto()', callNext)
  //     }
  //     countNext++;
  //     bngApi.engineLua('require("screenshot").takeScreenShot()', callNext)
  //   })
  // }

  vm.doScreenshot = function() {
    timedCall(next => {
      bngApi.engineLua('require("screenshot").takeScreenShot()', next)
    })
  }

  vm.doBigScreenShot = function() {
    timedCall(next => {
      bngApi.engineLua('require("screenshot").takeBigScreenShot()', next)
    })
  }

  vm.doHugeScreenShot = function() {
    timedCall(next => {
      bngApi.engineLua('require("screenshot").takeHugeScreenShot()', next)
    })
  }

  vm.sharePic = function() {
    timedCall(next => {
      bngApi.engineLua('screenshot.publish()', next)
    })
  }

  vm.steamPic = function () {
    /// note: leaving this as a commented code because it looked different
    // vm.showControls = false
    // //$scope.$emit callback system not working, so moved the UI hide before cursor hide in TS
    // bngApi.engineLua("extensions.ui_visibility.set(false)")
    // //Waiting to make sure hide has executed
    // Utils.waitForCefAndAngular(() => {
    //     bngApi.engineScript('hideCursor();', () => {
    //       bngApi.engineLua('screenshot.doSteamScreenshot()', () => {
    //         bngApi.engineLua("extensions.ui_visibility.set(true)")
    //         vm.showControls = true
    //         bngApi.engineScript('showCursor();')
    //         $scope.$apply()
    //       })
    //     })
    // })
    timedCall(next => {
      bngApi.engineLua('screenshot.doSteamScreenshot()', next)
    })
  }

  vm.openScreenshotsFolderInExplorer = function(){
    bngApi.engineLua('screenshot.openScreenshotsFolderInExplorer()')
  }

  vm.toggleSettings = function () {
    vm.settings.visible = !vm.settings.visible
  }

  vm.enableWatchers = function() {

    // Controls
    $scope.$watch('photo.settings.fov', function(value) {
      bngApi.engineLua('core_camera.setFOV(0, ' + value + ')')
    })

    $scope.$watch('photo.settings.cameraSpeed', function(value) {
      bngApi.engineLua( 'core_camera.setSpeed(' + value + ')' )
    })

    $scope.$watch('photo.settings.roll', function (value) {
      bngApi.engineLua('core_camera.rollAbs(' + (value * 1000) + ')' ); // in rads
    })

    $scope.$watch('photo.settings.colorCorrectionStrength', function(value) {
      bngApi.engineScript('PostEffectCombinePassObject.colorCorrectionStrength = ' + value + ';')
    })

    // Bloom
    $scope.$watch('photo.settings.bloomThreshold', function(value) {
      bngApi.engineLua('scenetree.PostEffectBloomObject.threshHold = (' + value + ');')
    })

    // DOF
    $scope.$watch('photo.settings.dofAutofocus', function(value) {
      bngApi.engineScript('$DOFPostFx::EnableAutoFocus = ' + value + ';')
      // Store the previous focus range value when enabling autofocus
      if (value) {
        vm.previousFocusRange = vm.settings.dofFocusRange
        vm.settings.dofFocusRange = 0
      } else {
        // Restore the previous focus range when disabling autofocus
        if (vm.previousFocusRange !== undefined) {
          vm.settings.dofFocusRange = vm.previousFocusRange
        }
      }
      bngApi.engineLua('require("client/postFx/dof").updateDOFSettings()')
    })

    $scope.$watch('photo.settings.dofMaxBlurNear', function(value) {
      bngApi.engineScript('$DOFPostFx::BlurMin = ' + value + ';')
      bngApi.engineLua('require("client/postFx/dof").updateDOFSettings()')
    })

    $scope.$watch('photo.settings.dofMaxBlurFar', function(value) {
      bngApi.engineScript('$DOFPostFx::BlurMax = ' + value + ';')
      bngApi.engineLua('require("client/postFx/dof").updateDOFSettings()')
    })

    $scope.$watch('photo.settings.dofFocusRange', function(value) {
      bngApi.engineScript('$DOFPostFx::FocusRangeMax = ' + value + ';')
      bngApi.engineLua('require("client/postFx/dof").updateDOFSettings()')
    })

    $scope.$watch('photo.settings.dofAperture', function(value) {
      bngApi.engineScript('$DOFPostFx::BlurCurveFar = ' + value + ';')
      bngApi.engineLua('require("client/postFx/dof").updateDOFSettings()')
    })

    $scope.$watch('photo.settings.dofFalloffSharpness', function(value) {
      bngApi.engineScript('$DOFPostFx::FocusRangeMin = ' + value + ';')
      bngApi.engineLua('require("client/postFx/dof").updateDOFSettings()')
    })

    // SSAO
    $scope.$watch('photo.settings.SSAOContrast', function(value) {
      bngApi.engineLua('scenetree.SSAOPostFx:setContrast(' + value + ');')
    })

    $scope.$watch('photo.settings.SSAORadius', function(value) {
      bngApi.engineLua('scenetree.SSAOPostFx:setRadius(' + value + ');')
    })

    $scope.$watch('photo.settings.SSAOQuality', function(value) {
      if (value == 1) {
        $scope.photo.settings.SSAOQualityText = $translate.instant("ui.photomode.SSAOQualityNormal")
        bngApi.engineLua('scenetree.SSAOPostFx:setSamples(16);')
      }
      if (value == 2) {
        $scope.photo.settings.SSAOQualityText = $translate.instant("ui.photomode.SSAOQualityHigh")
        bngApi.engineLua('scenetree.SSAOPostFx:setSamples(64);')
      }
    })

    // Rendering, use with caution
    //console.log(vm.advancedSettings)
    if (true) {
      // Shadows
      $scope.$watch('photo.settings.shadowSize', function(value) {
        $scope.shadowSizeLabel = 1024; // Default slider text value
        if (vm.advancedSettings) { // This ensures shadow is not modified until the slider is operated
          shadowRes = Math.pow(2, value)
          bngApi.engineScript('sunsky.texSize = ' + shadowRes + ';')
          $scope.shadowSizeLabel = shadowRes
        }
      })

      $scope.$watch('photo.settings.shadowDistance', function(value) {
        bngApi.engineScript('sunsky.shadowDistance =' + value + ';')
      })

      $scope.$watch('photo.settings.logWeight', function(value) {
        bngApi.engineScript('sunsky.logWeight =' + value + ';')
      })

      // Level of Details
      $scope.$watch('photo.settings.detailAdjust', function(value) {
        bngApi.engineScript('$pref::TS::detailAdjust =' + value + ';')
      })

      $scope.$watch('photo.settings.lodScale', function(value) {
        bngApi.engineScript('$pref::Terrain::lodScale =' + value + ';')
      })

      $scope.$watch('photo.settings.GroundCoverScale', function(value) {
        bngApi.engineScript('setGroundCoverScale(' + value + ');')
      })
    }
  }

  vm.openPostFXManager = function() {
    console.log("openPostFXManager")
    bngApi.engineScript('Canvas.pushDialog(PostFXManager);')
  }

  //get ssao quality
  bngApi.engineLua('settings.getValue("PostFXSSAOGeneralQuality")',
    (data) => {
      $scope.$evalAsync(() => {
        vm.PostFXSSAOGeneralQuality = data
        if (data == "Low") {
          vm.settings.SSAOQuality = 1
        }
        if (data == "High") {
          vm.settings.SSAOQuality = 2
        }
      })
    }
  )

  bngApi.engineLua('core_environment.getTimeOfDay()',
    (data) => {
      $scope.$evalAsync(() => {
        vm.storedTime = data
      })
    }
  )

  // Get time in 24 hours format
  $scope.$watch('photo.environment.state.time', function(value) {
    bngApi.engineLua('getTimeOfDay(true)',
    (data) => {
      $scope.$evalAsync(() => {
        $scope.timeAsString = data
      })
    })
  })

  // Get azimuthOverride
  $scope.$watch('photo.environment.state.azimuthOverride', function(value) {
    bngApi.engineLua('core_environment.getTimeOfDay(true)',
    (data) => {
      $scope.$evalAsync(() => {
        $scope.azimuthOverride = data.azimuthOverride
        $scope.azimuthOverrideAsDegrees = (data.azimuthOverride/Math.PI) * 180
      })
    })
  })


  // Color Correction
  vm.colorCorrectionRamps = {}
  bngApi.engineLua('require("util/renderComponentsAPI").getColorCorrections()',
  (data) => {
    $scope.$evalAsync(() => {
      vm.colorCorrectionRamps = data
    })
  })

  vm.setColorCorrectionRamp = function ($event, filename) {
    if (filename == -1) {
      // Reset to default
      resetColorCorrectionRamp()
      $scope.showFilterStrength = "1"
    }
    else {
      bngApi.engineScript(`PostEffectCombinePassObject.colorCorrectionRampPath = "${filename}";`)
    }
  }

  function resetColorCorrectionRamp() {
    bngApi.engineScript(`PostEffectCombinePassObject.colorCorrectionRampPath = "";`)
  }
  resetColorCorrectionRamp(); //Make sure default is loaded when opening photomode


  // Overlays
  vm.photomodeOverlays = {}
  bngApi.engineLua('require("util/photomode").getPhotomodeOverlays()',
  (data) => {
    $scope.$evalAsync(() => {
      vm.photomodeOverlays = data
    })
  })

  $scope.selectedOverlay = 'menu_template.png';
  $scope.overlaySelected = function(overlay) {
      $scope.selectedOverlay = overlay;
  };

  vm.nodeGrabberVisible = false;
  vm.toggleNodeGrabberVisibility = function () {
    bngApi.engineLua(`Engine.NodeGrabber_setFixedNodesVisible(${!!vm.nodeGrabberVisible})`);
  }

  // Extra features
  vm.resetTireMarks = function(){
    bngApi.engineLua('be:resetTireMarks()')
  }

  vm.resetPostFX = function() {
    bngApi.engineLua('postFxModule.loadPresetFile("lua/ge/client/postFx/presets/defaultPostfxPreset.postfx"); postFxModule.settingsApplyFromPreset()')
  }

  vm.extraFeatures = photomodeExtraFeatures.enabled
  vm.photomodeExtraFeatures = photomodeExtraFeatures

  // Watch for changes to persist them
  $scope.$watch('photo.extraFeatures', function(newVal) {
    photomodeExtraFeatures.enabled = newVal
  })

  $scope.$watch('photo.photomodeExtraFeatures.expanded', function(newVal) {
    photomodeExtraFeatures.expanded = newVal
  })

  vm.savedCamera = photomodeSavedCamera.data
  vm.savedSettings = photomodeSavedSettings.data

  vm.saveCameraPos = function() {
    bngApi.engineLua('core_camera.getPosition()', (pos) => {
      bngApi.engineLua('core_camera.getQuat()', (rot) => {
        bngApi.engineLua('core_camera.getFovDeg()', (fov) => {
          vm.savedCamera = {
            pos: pos,
            rot: rot,
            fov: fov
          }
          photomodeSavedCamera.data = vm.savedCamera
        })
      })
    })
  }

  vm.loadCameraPos = function() {
    if (!vm.savedCamera) return

    // Set FOV first
    vm.settings.fov = vm.savedCamera.fov
    bngApi.engineLua('core_camera.setFOV(0, ' + vm.savedCamera.fov + ')')

    // Then set camera position and rotation
    bngApi.engineLua(`core_camera.setPosRot(0, ${vm.savedCamera.pos.x}, ${vm.savedCamera.pos.y}, ${vm.savedCamera.pos.z}, ${vm.savedCamera.rot.x}, ${vm.savedCamera.rot.y}, ${vm.savedCamera.rot.z}, ${vm.savedCamera.rot.w})`)
  }

  vm.saveSettings = function() {
    vm.savedSettings = {
      // Time settings
      time: vm.environment.state.time,
      azimuthOverride: vm.environment.state.azimuthOverride,

      // PostFX settings
      bloomThreshold: vm.settings.bloomThreshold,

      // DOF settings
      dofMaxBlurNear: vm.settings.dofMaxBlurNear,
      dofMaxBlurFar: vm.settings.dofMaxBlurFar,
      dofFocusRange: vm.settings.dofFocusRange,
      dofAperture: vm.settings.dofAperture,
      dofFalloffSharpness: vm.settings.dofFalloffSharpness,

      // SSAO settings
      SSAOContrast: vm.settings.SSAOContrast,
      SSAORadius: vm.settings.SSAORadius,
      SSAOQuality: vm.settings.SSAOQuality
    }
    photomodeSavedSettings.data = vm.savedSettings
  }

  vm.loadSettings = function() {
    if (!vm.savedSettings) return

    // Sun position first
    vm.environment.state.azimuthOverride = vm.savedSettings.azimuthOverride
    vm.environment.submitState()

    // Then time settings
    vm.environment.state.time = vm.savedSettings.time
    vm.environment.submitState()

    // PostFX settings
    vm.settings.bloomThreshold = vm.savedSettings.bloomThreshold
    bngApi.engineLua('scenetree.PostEffectBloomObject.threshHold = (' + vm.savedSettings.bloomThreshold + ');')

    // DOF settings
    vm.settings.dofMaxBlurNear = vm.savedSettings.dofMaxBlurNear
    vm.settings.dofMaxBlurFar = vm.savedSettings.dofMaxBlurFar
    vm.settings.dofFocusRange = vm.savedSettings.dofFocusRange
    vm.settings.dofAperture = vm.savedSettings.dofAperture
    vm.settings.dofFalloffSharpness = vm.savedSettings.dofFalloffSharpness
    bngApi.engineLua('require("client/postFx/dof").updateDOFSettings()')

    // SSAO settings
    vm.settings.SSAOContrast = vm.savedSettings.SSAOContrast
    vm.settings.SSAORadius = vm.savedSettings.SSAORadius
    vm.settings.SSAOQuality = vm.savedSettings.SSAOQuality
    bngApi.engineLua('scenetree.SSAOPostFx:setContrast(' + vm.savedSettings.SSAOContrast + ');')
    bngApi.engineLua('scenetree.SSAOPostFx:setRadius(' + vm.savedSettings.SSAORadius + ');')
    bngApi.engineLua('scenetree.SSAOPostFx:setSamples(' + (vm.savedSettings.SSAOQuality == 1 ? '16' : '64') + ');')
  }

  vm.toggleDOFAutofocus = function () {
    bngApi.engineScript('$DOFPostFx::EnableAutoFocus = ' + vm.settings.dofAutofocus + ';')
    // The watcher will handle the focus range changes
    bngApi.engineLua('require("client/postFx/dof").updateDOFSettings()')
  }

  $scope.$on('$destroy', function() {
    window.bridge.uiNavEvents.clearFilteredEvents()
    //console.debug('Exiting photomode')
    bngApi.engineLua("photoModeOpen = false"); // yes, this is horrible
    bngApi.engineLua("if core_camera.getActiveCamName() ~= 'path' then commands.setGameCamera() end"); // camera change if the editor was not loaded before
    bngApi.engineLua("MoveManager.rollRelative = 0; if core_camera.savedCameraFov then core_camera.setFOV(0, core_camera.savedCameraFov) end")
    showPhotomodeGrid.show = vm.settings.showGrid

    // Only restore settings if keepSettingsOnExit is false
    if (!vm.keepSettingsOnExit) {
      // Reset sun direction first
      vm.environment.state.azimuthOverride = vm.storedTime.azimuthOverride
      vm.environment.submitState()

      // Then reset time
    vm.environment.state.time = vm.storedTime.time
      vm.environment.submitState()

    // Make UI visible
    bngApi.engineLua("ui_visibility.set(true)")

    // Reset PostFX
    // bngApi.engineScript('DOFPostEffect.setAutoFocus(false);')
    bngApi.engineLua('scenetree.PostEffectBloomObject.threshHold = 3.5;')
    // Disable DOF autofocus
    bngApi.engineScript('$DOFPostFx::EnableAutoFocus = false;')
    bngApi.engineLua('require("client/postFx/dof").updateDOFSettings()')

    bngApi.engineLua('scenetree.SSAOPostFx:setContrast(2)')
    bngApi.engineLua('scenetree.SSAOPostFx:setRadius(1.5)')
    if (vm.PostFXSSAOGeneralQuality == "Low") {
      bngApi.engineLua('scenetree.SSAOPostFx:setSamples(16)')
    }
    if (vm.PostFXSSAOGeneralQuality == "High") {
      bngApi.engineLua('scenetree.SSAOPostFx:setSamples(64)')
    }
    bngApi.engineLua(`require('util/renderComponentsAPI').setMultiSettings( ${bngApi.serializeToLua(vm.originalPostSettings)} )`)
    resetColorCorrectionRamp()
    }

    bngApi.engineLua('Engine:NodeGrabber_setFixedNodesVisible(true)')
  })
}])

