angular.module("beamng.stuff")


.controller("startScreenController", ["$scope", "$state", "$timeout", "$interval", function($scope, $state, $timeout, $interval) {
  // note: $timeout and $interval participate in $digest lifecycle, which helps

  // see comment in main.js about the process
  if ($state.current.name === "menu.start") {
    // 1) after the start screen is loaded, start loading the main menu
    $timeout(() => {
      $state.go("menu.start_loadmainmenu");
    }, 300);
  } else if($state.current.name === "menu.start_loadmainmenu") {
    // 2) after the main menu is loaded, switch to it
    //    but this time, more carefully

    $scope.hasTransitioned = false;

    // main timeout
    $timeout(() => {
      if (!$scope.hasTransitioned) {
        $scope.hasTransitioned = true;
        $state.go("menu.mainmenu");
      }
    }, 2700);

    // backup
    const stateChecker = $interval(function () {
      if (!$scope.hasTransitioned) {
        // check if the Overpass font has loaded - usually that's the indication of vue being ready and already rendering mainmenu
        if (document.fonts && document.fonts.check("1em Overpass")) {
          $scope.hasTransitioned = true;
          $state.go("menu.mainmenu");
          $interval.cancel(stateChecker);
        }
      } else {
        $interval.cancel(stateChecker);
      }
    }, 500, 60); // max 60 attempts (30 sec total)

    $scope.$on("$destroy", function () {
      if (stateChecker) $interval.cancel(stateChecker);
    });
  }

}]);