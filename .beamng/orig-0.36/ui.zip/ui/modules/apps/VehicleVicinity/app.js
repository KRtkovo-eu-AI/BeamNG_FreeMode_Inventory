angular.module('beamng.apps')
.directive('vehicleVicinityApp', [function () {
  return {
    template: '<svg style="width: 100%; height: 100%; border:1px solid black;background:rgba(0,0,0,0.3);box-sizing: border-box;"></svg>',
    replace: true,
    link: function ($scope, element, attrs) {
      let svg = element[0];
      element.css({'transform': "scale(-1,1)"})

      let objectCache = {};
      let gridGroup = null;
      let centerDot = null;
      let scaleLine = null;

      let lastViewBoxSize = 0;

      function drawGrid(viewBoxSize, gridSize) {
        // Only create grid if it doesn't exist or viewbox size changed
        if (!gridGroup) {
          gridGroup = hu('<g>', svg).attr({ stroke: 'grey', 'stroke-width': 0.02 });
          lastViewBoxSize = viewBoxSize;
        } else if (lastViewBoxSize !== viewBoxSize) {
          gridGroup.innerHTML = '';
          lastViewBoxSize = viewBoxSize;
        } else {
          return;
        }

        // Draw horizontal and vertical grid lines
        for (let i = -viewBoxSize / 2; i <= viewBoxSize / 2; i += gridSize) {
          hu('<line>', gridGroup).attr({ x1: i, y1: -viewBoxSize / 2, x2: i, y2: viewBoxSize / 2 });
          hu('<line>', gridGroup).attr({ x1: -viewBoxSize / 2, y1: i, x2: viewBoxSize / 2, y2: i });
        }
      }

      function rotatePoint(x, y, angle) {
        return {
          x: x * Math.cos(angle) - y * Math.sin(angle),
          y: x * Math.sin(angle) + y * Math.cos(angle)
        };
      }

      function createArrowHead(x, y, vehicleWidth, vehicleHeight, group) {
        // Define the aspect ratio and calculate the arrowhead dimensions
        const aspectRatio = 2; // Width is twice the height
        const arrowWidth = vehicleWidth / 2; // Half of the vehicle's width
        const arrowHeight = arrowWidth / aspectRatio; // Calculate height based on the aspect ratio

        const points = [
          `${x}, ${y - vehicleHeight / 4}`, // Top point (base of the arrow at the front of the vehicle)
          `${x - arrowWidth / 2}, ${y - vehicleHeight / 4 + arrowHeight}`, // Bottom left
          `${x + arrowWidth / 2}, ${y - vehicleHeight / 4 + arrowHeight}` // Bottom right
        ].join(' ');

        return hu('<polygon>', group).attr({
          points: points,
          fill: 'white'
        });
      }

      $scope.$on('onVehicleVicinityData', function (event, data) {
        let plObject = data.objects[data.playerVehicleId];
        let vehicleRotation = -plObject.rotX;
        let viewBoxSize = Math.max(plObject.sizeX, plObject.sizeY) * 5;

        drawGrid(viewBoxSize, 1); // Grid size set to 1 meter

        // Track which objects are still present in this update
        let currentObjectIds = new Set(Object.keys(data.objects));

        // Remove objects that are no longer present
        for (var cachedId in objectCache) {
          if (!currentObjectIds.has(cachedId)) {
            let cached = objectCache[cachedId];
            if (cached.group && cached.group.remove) {
              cached.group.remove();
            }
            if (cached.couplers && cached.couplers.length > 0) {
              cached.couplers.forEach(coupler => {
                if (coupler && coupler.remove) coupler.remove();
              });
            }
            delete objectCache[cachedId];
          }
        }

        // Update or create objects
        for (var id in data.objects) {
          let object = data.objects[id];
          let position = rotatePoint(
            object.centerX - plObject.centerX,
            object.centerY - plObject.centerY,
            vehicleRotation
          );

          let color = 'blue'
          if(object.type === 'traffic') {
            color = 'grey'
          } else if(object.type === 'parked') {
            color = 'grey'
          } else if(object.type === 'trailer') {
            color = 'green'
          }

          let isPlayer = (id == data.playerVehicleId)
          let objectRotation = object.rotX - plObject.rotX;

          // Create an object
          if (!objectCache[id]) {
            let group = hu('<g>', svg);
            let rect = hu('<rect>', group);
            let arrow = null;

            objectCache[id] = {
              group: group,
              rect: rect,
              arrow: arrow,
              couplers: [],
            };
          }

          // Update object properties using local coordinates relative to group
          let cached = objectCache[id];
          cached.rect.attr({
            x: -object.sizeX / 2,
            y: -object.sizeY / 2,
            width: object.sizeX,
            height: object.sizeY,
            fill: color,
            rx: 0.1, // Rounded corner radius (horizontal)
            ry: 0.1, // Rounded corner radius (vertical)
            stroke: isPlayer ? 'orange' : 'black',
            'stroke-width': isPlayer ? 0.1 : 0.05
          });

          // Create arrow with local coordinates (centered at vehicle origin)
          if (!cached.arrow) {
            cached.arrow = createArrowHead(0, -object.sizeY / 4, object.sizeX, object.sizeY, cached.group);
          }

          // Position and rotate group at world coordinates
          cached.group.attr('transform', `translate(${position.x}, ${position.y}) rotate(${objectRotation * 180 / Math.PI})`);

          // Handle couplers
          if (object.couplers && Object.keys(object.couplers).length > 0) {
            let couplerData = Object.values(object.couplers);

            // Only recreate couplers if the count changed
            if (cached.couplers.length !== couplerData.length) {
              cached.couplers.forEach(coupler => {
                if (coupler && coupler.remove) coupler.remove();
              });
              cached.couplers = [];

              for (let i = 0; i < couplerData.length; i++) {
                let couplerCircle = hu('<circle>', svg).attr({
                  r: 0.4,
                  fill: 'red'
                });
                cached.couplers.push(couplerCircle);
              }
            }

            // Update existing coupler positions
            for (let i = 0; i < couplerData.length; i++) {
              let couplerNode = couplerData[i];
              if (!cached.couplers[i]) continue;

              let positionC = rotatePoint(
                couplerNode.livePos.x - plObject.centerX,
                couplerNode.livePos.y - plObject.centerY,
                vehicleRotation
              );

              cached.couplers[i].attr({
                cx: positionC.x,
                cy: positionC.y
              });
            }
          } else if (cached.couplers.length > 0) {
            // Remove all couplers if none exist
            cached.couplers.forEach(coupler => {
              if (coupler && coupler.remove) coupler.remove();
            });
            cached.couplers = [];
          }
        }

        // Create center dot
        if (!centerDot) {
          centerDot = hu('<circle>', svg).attr({
            cx: 0,
            cy: 0,
            r: 0.02,
            fill: 'red'
          });
        }

        svg.setAttribute('viewBox', `${-viewBoxSize / 2} ${-viewBoxSize / 2} ${viewBoxSize} ${viewBoxSize}`);

        // add a legend
        if (!scaleLine) {
          let scaleLineLength = 1
          let lineYPosition = viewBoxSize / 2 - 1
          let lineXPosition = -viewBoxSize / 2 - 2
          scaleLine = hu('<line>', svg).attr({
            x1: lineXPosition,
            y1: lineYPosition,
            x2: lineXPosition + scaleLineLength,
            y2: lineYPosition,
            stroke: 'black',
            'stroke-width': 0.05
          });
        } else {
          // Update scale line position
          let scaleLineLength = 1
          let lineYPosition = viewBoxSize / 2 - 1
          let lineXPosition = -viewBoxSize / 2 - 2
          scaleLine.attr({
            x1: lineXPosition,
            y1: lineYPosition,
            x2: lineXPosition + scaleLineLength,
            y2: lineYPosition
          });
        }
      });

      $scope.$on('$destroy', function () {
        objectCache = {};
        gridGroup = null;
        centerDot = null;
        scaleLine = null;
        lastViewBoxSize = 0;
        svg.innerHTML = '';
        bngApi.engineLua('extensions.unload("ui_vehicleVicinityApp")')
      })
      bngApi.engineLua('extensions.load("ui_vehicleVicinityApp")')
    }
  }
}]);
