angular.module('beamng.apps')
  .directive('drivingStrategy', [function () {
    return {
      template:
        '<object class="bngApp" style="width:100%; height:100%; pointer-events: none" type="image/svg+xml" data="/ui/modules/apps/DrivingStrategy/driving-strategy.svg"></object>',
      replace: true,
      restrict: 'EA',
      link: function (scope, element, attrs) {
        StreamsManager.add(['drivingStrategy'])

        scope.$on('$destroy', function () {
          StreamsManager.remove(['drivingStrategy'])
        })

        // used to debug controller deadzones: any input that is not exactly 0 or exactly <max> will get rounded to a different number than those
        // e.g. if we use a max of 100 (to display percentages)
        // 0 rounds to 0%
        // 0.01 rounds to 1%
        // 0.99 rounds to 1%
        // ...
        // 99.01 rounds to 99%
        // 99.99 rounds to 99%
        // 100 rounds to 100%
        let smartRound = function (max, v) {
          return v >= max ? max : Math.floor(v + (1 - 1e-7 - v / max))
        }
        element.on('load', function () {
          var svg = element[0].contentDocument
            , drift = { bar: svg.getElementById('filler0'), txt: svg.getElementById('txt0'), val: svg.getElementById('val0'), container: svg.getElementById('container0'), factor: svg.getElementById('container0').getAttribute('height') / 100.0 }
            , track = { bar: svg.getElementById('filler1'), txt: svg.getElementById('txt1'), val: svg.getElementById('val1'), container: svg.getElementById('container1'), factor: svg.getElementById('container1').getAttribute('height') / 100.0 }
            , offroad = { bar: svg.getElementById('filler2'), txt: svg.getElementById('txt2'), val: svg.getElementById('val2'), container: svg.getElementById('container2'), factor: svg.getElementById('container2').getAttribute('height') / 100.0 }
            , street = { bar: svg.getElementById('filler3'), txt: svg.getElementById('txt3'), val: svg.getElementById('val3'), container: svg.getElementById('container3'), factor: svg.getElementById('container3').getAttribute('height') / 100.0 }


          scope.$on('streamsUpdate', function (event, streams) {
            if (streams != null && streams.drivingStrategy != null) {
              var driftVal = Math.round(streams.drivingStrategy.probabilities.drift * 100)
                , trackVal = Math.round(streams.drivingStrategy.probabilities.track * 100)
                , offroadVal = Math.round(streams.drivingStrategy.probabilities.offroad * 100)
                , streetVal = Math.round(streams.drivingStrategy.probabilities.street * 100)

              drift.val.innerHTML = driftVal
              track.val.innerHTML = trackVal
              offroad.val.innerHTML = offroadVal
              street.val.innerHTML = streetVal

              drift.txt.innerHTML = "drift"
              track.txt.innerHTML = "track"
              offroad.txt.innerHTML = "offroad"
              street.txt.innerHTML = "street"

              drift.txt.style.opacity = driftVal == 0 ? 0.75 : 1
              drift.val.style.opacity = driftVal == 0 ? 0.75 : 1
              track.txt.style.opacity = trackVal == 0 ? 0.75 : 1
              track.val.style.opacity = trackVal == 0 ? 0.75 : 1
              offroad.txt.style.opacity = offroadVal == 0 ? 0.75 : 1
              offroad.val.style.opacity = offroadVal == 0 ? 0.75 : 1
              street.txt.style.opacity = streetVal == 0 ? 0.75 : 1
              street.val.style.opacity = streetVal == 0 ? 0.75 : 1

              drift.bar.setAttribute('height', isNaN(driftVal) ? 0 : driftVal * drift.factor)
              track.bar.setAttribute('height', isNaN(trackVal) ? 0 : trackVal * track.factor)
              offroad.bar.setAttribute('height', isNaN(offroadVal) ? 0 : offroadVal * offroad.factor)
              street.bar.setAttribute('height', isNaN(streetVal) ? 0 : streetVal * street.factor)
            }
          })
        })
      }
    }
  }])
