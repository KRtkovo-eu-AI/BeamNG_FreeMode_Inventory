// vim: ts=2 sw=2

angular.module('beamng.apps').directive('rallyRecce', ['$interval', '$sce', '$timeout', '$translate', function ($interval, $sce, $timeout, $translate) {
  return {
    templateUrl: '/ui/modules/apps/RallyRecce/app.html',
    replace: true,
    controller: ['$log', '$scope', function ($log, $scope) {
      'use strict'

      // load the lua extension backing this UI app.
      bngApi.engineLua('extensions.load("gameplay_rally")')


      let transcriptRefreshIntervalMs = 250

      $scope.isRecording = false
      $scope.showNotes = false

      // $scope.missionIsLoaded = false
      $scope.missionLoadMessage = null
      $scope.loadedMission = null
      $scope.lastLoadSuccess = true

      $scope.clear1Enabled = false

      $scope.recordDriveline = false
      $scope.recordVoice = false

      $scope.missions = []
      $scope.lastAttemptedLoadMission = null
      $scope.selectedMission = null

      let transcriptInterval = null

      function refreshRecceApp() {
        bngApi.engineLua('gameplay_rally.recceApp.reload()')
      }

      function updateLuaShowNotes() {
        bngApi.engineLua('gameplay_rally.recceApp.setShowNotes('+$scope.showNotes+')')
      }

      $scope.btnDevTools = function() {
        bngApi.engineLua('gameplay_rally.recceApp.toggleRallyToolbox()')
      }

      $scope.$on('$destroy', function () {
        // StreamsManager.remove(streamsList)
        // only unload if in freeroam
        bngApi.engineLua('if core_gamestate.state and core_gamestate.state.state == "freeroam" then extensions.unload("gameplay_rally") end')
      })

      $scope.$on('rally.onExtensionLoaded', function (event, response) {
        bngApi.engineLua('gameplay_rally.enableRecceApp(true)')
        refreshRecceApp()
      })

      $scope.$on('rally.recceApp.refreshed', function (event, response) {
        // console.log('recce missions loaded: ' + JSON.stringify(response))

        let missions = response.missions
        let last_mid = response.last_mission_id
        let last_load_state = response.last_load_state
        // console.log(`recce last_mission_id=${last_mid} loaded=${last_load_state}`)

        if (Object.keys(missions).length === 0 && !Array.isArray(missions)) {
          $scope.missions = []
        } else {
          $scope.missions = missions
        }

        // console.log('missions='+JSON.stringify($scope.missions))

        if ($scope.missions && $scope.missions.length > 0) {
          $scope.selectedMission = null

          $scope.selectedMission = $scope.missions.find((mission) => mission.missionId === last_mid)

          if (!$scope.selectedMission) {
            $scope.selectedMission = $scope.missions[0]
          }

          // console.log('selectedMission='+JSON.stringify($scope.selectedMission))
          if (last_load_state) {
            $scope.btnLoadMission()
          }
        } else {
          $scope.missions = []
          $scope.selectedMission = null
        }
      })

      $scope.$on('rallyInputActionCutRecording', function (event) {
        $scope.btnRecordCut()

        if ($scope.isRecording) {
          var cutBtn = angular.element(document.getElementById('cut-btn'))
          cutBtn.addClass('cut-fake-click')
          $timeout(function() {
            cutBtn.removeClass('cut-fake-click')
          }, 150);
        }
      })

      $scope.$on('rallyInputActionRecceMoveVehicleForward', function (event) {
        $scope.btnMoveVehicleForward()
      })

      $scope.$on('rallyInputActionRecceMoveVehicleBackward', function (event) {
        $scope.btnMoveVehicleBackward()
      })

      $scope.btnRefreshMissions = function() {
        refreshRecceApp()
      }

      $scope.btnLoadMission = function() {
        if ($scope.selectedMission) {
          // console.log('btnLoadMission: selectedMission='+JSON.stringify($scope.selectedMission))
          const missionToLoadId = $scope.selectedMission.missionId
          const missionToLoadDir = $scope.selectedMission.missionDir
          $scope.missionLoadMessage = "loading mission..."
          $scope.lastLoadSuccess = true
          bngApi.engineLua('gameplay_rally.recceApp.loadMission("'+missionToLoadId+'", "'+missionToLoadDir+'")')
          updateLuaShowNotes()
        }
      }

      $scope.$on('rally.recceApp.missionLoaded', function (event, success, errorMsgForUser) {
        // console.log('missionLoaded: '+missionId+' success='+success+' errorMsgForUser='+errorMsgForUser)
        if (success) {
          $scope.loadedMission = $scope.selectedMission
          $scope.missionLoadMessage = null
          $scope.lastLoadSuccess = true
        }
        else {
          $scope.lastLoadSuccess = false
          if (errorMsgForUser) {
            $scope.missionLoadMessage = errorMsgForUser
          } else {
            $scope.missionLoadMessage = "failed to load mission"
          }
          $scope.loadedMission = null
        }
      })

      $scope.btnUnloadMission = function() {
        bngApi.engineLua('gameplay_rally.recceApp.unloadMission()')
        $scope.missionLoadMessage = null
        $scope.loadedMission = null
        $scope.lastLoadSuccess = true
      }

      $scope.btnRecordStart = function() {
        $scope.isRecording = true

        transcriptInterval = $interval(() => {
          // bngApi.engineLua('if gameplay_rally then gameplay_rally.recceApp.desktopGetTranscripts() end')
        }, transcriptRefreshIntervalMs)

        bngApi.engineLua(`gameplay_rally.recceApp.recordDrivelineStart(${$scope.recordVoice})`)
      }

      $scope.btnRecordStop = function() {
        $scope.isRecording = false

        if (angular.isDefined(transcriptInterval)) {
          $interval.cancel(transcriptInterval)
        }

        bngApi.engineLua("gameplay_rally.recceApp.recordDrivelineStop()")
      }

      $scope.btnRecordCut = function() {
        if ($scope.isRecording) {
          bngApi.engineLua("gameplay_rally.recceApp.recordDrivelineCut()")
        }
      }

      $scope.btnClearAll = function() {
        $scope.clear1Enabled = false
        bngApi.engineLua("gameplay_rally.recceApp.recordDrivelineClearAll()")
      }

      $scope.btnClear1 = function() {
        if ($scope.clear1Enabled) {
          $scope.clear1Enabled = false
        } else {
          $scope.clear1Enabled = true
        }
      }

      $scope.btnToggleShowNotes = function() {
        $scope.showNotes = !$scope.showNotes
        updateLuaShowNotes()
      }

      $scope.btnMoveVehicleForward = function() {
        bngApi.engineLua('gameplay_rally.recceApp.moveVehicleForward()')
      }
      $scope.btnMoveVehicleBackward = function() {
        bngApi.engineLua('gameplay_rally.recceApp.moveVehicleBackward()')
      }
      $scope.btnMoveVehicleToStart = function() {
        bngApi.engineLua('gameplay_rally.recceApp.moveVehicleToStart()')
      }
      $scope.btnMoveVehicleToMission = function() {
        bngApi.engineLua('gameplay_rally.recceApp.moveVehicleToMission()')
      }
    }] // end controller
  } // end directive
}])
