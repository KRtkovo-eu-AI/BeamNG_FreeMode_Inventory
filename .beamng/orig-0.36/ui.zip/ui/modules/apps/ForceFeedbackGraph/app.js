angular.module('beamng.apps')
.directive('forceFeedbackGraph', function () {
  return {
    restrict: 'E',
    template: `
      <div>
        <canvas width="400" height="160"></canvas>
        <div class="md-caption" style="padding: 2px; color: silver; position: absolute; top: 0; left: 0; width: auto; height: auto; background-color: rgba(50, 50, 50, 0.9)" layout="column">
          <md-checkbox style="margin:0px" ng-model="showForces">{{:: 'ui.apps.ffb_graph.Force' | translate}}</md-checkbox>
          <span ng-show="showForces" layout="column">
              <span style="color: #FD9393; margin:0px">{{:: 'ui.apps.ffb_graph.Atdriver' | translate}}: {{ sensors.forceAtDriverNorm * sensors.torqueCurrent|number:2}}%</span>
              <span style="color: #FF4343; margin:0px">{{:: 'ui.apps.ffb_graph.Atwheel' | translate}}: {{ sensors.forceAtWheelNorm * sensors.torqueCurrent|number:2}}%</span>
              <span style="color: #999999; margin:0px">{{:: 'ui.apps.ffb_graph.Limit' | translate}}: &plusmn;{{ sensors.curForceLimitNorm * sensors.torqueCurrent|number:2}}%</span>
          </span>
          <md-checkbox style="margin:0px" ng-model="showInput">{{:: 'ui.apps.ffb_graph.Input' | translate}}</md-checkbox>
          <span ng-show="showInput" layout="column">
              <span style="color: #A8DD73; margin:0px">{{:: 'ui.apps.ffb_graph.Steering' | translate}}: {{ input * 100|number:2}}%</span>
              <span style="color: #A8DD73; margin:0px">{{:: 'ui.apps.ffb_graph.MaxSteering' | translate}}: {{ maxInput * 100|number:2}}%</span>
          </span>
        </div>
      </div>`,
    replace: true,
    link: function (scope, element, attrs) {
      var streamsList = ['sensors', 'electrics']
      StreamsManager.add(streamsList)
      scope.$on('$destroy', function () {
        StreamsManager.remove(streamsList)
      })

      scope.showForces = true
      scope.showInput = true
      var canvas = element[0].children[0]
      var chart = new SmoothieChart({
          minValue: -1.0,
          maxValue: 1.0,
          millisPerPixel: 20,
          interpolation: 'linear',
          grid: { fillStyle: 'rgba(0,0,0,0.43)', strokeStyle: 'black', verticalSections: 4, millisPerLine: 1000, sharpLines: true }
        })
        , ffbAtDriverGraph=new TimeSeries()
        , ffbAtWheelGraph= new TimeSeries()
        , steerGraph     = new TimeSeries({"resetBoundsInterval":250})
        , maxffbGraphPos = new TimeSeries()
        , maxffbGraphNeg = new TimeSeries()
        , steerLine     = { strokeStyle: '#A8DD73', lineWidth: 3 }
        , maxffbLinePos = { strokeStyle: '#999999', lineWidth: 2 }
        , maxffbLineNeg = { strokeStyle: '#999999', lineWidth: 2 }
        , ffbAtDriverLine={ strokeStyle: '#FD9393', lineWidth: 2 }
        , ffbAtWheelLine= { strokeStyle: '#FF4343', lineWidth: 2 }


      let pausedTime = 0
      chart.addTimeSeries(steerGraph,     steerLine)
      chart.addTimeSeries(maxffbGraphPos, maxffbLinePos)
      chart.addTimeSeries(maxffbGraphNeg, maxffbLineNeg)
      chart.addTimeSeries(ffbAtDriverGraph,            ffbAtDriverLine)
      chart.addTimeSeries(ffbAtWheelGraph,      ffbAtWheelLine)
      chart.streamTo(canvas, 40+pausedTime)

      scope.sensors = {
        curForceLimitNorm: 0,
        forceAtDriverNorm: 0,
        forceAtWheelNorm: 0,
        torqueCurrent: null,
      }
      scope.input = 0

      let lastPaused = undefined
      scope.$on('streamsUpdate', function (event, streams) {
        if (!streams.sensors || !streams.electrics) { return }

        let now = new Date().getTime()
        if (scope.$parent.$parent.app.showPauseIcon) {
          if (lastPaused === undefined) {
            lastPaused = now
            chart.stop()
          }
          return
        }
        if (lastPaused !== undefined) {
          pausedTime += now - lastPaused
          lastPaused = undefined
          chart.streamTo(canvas, 40+pausedTime)
          chart.start()
        }

        let dataTime = now - pausedTime
        if (scope.showInput) {
          steerGraph.append(dataTime, streams.electrics.steering_input);   // current steering
        }
        if (scope.showForces) {
          maxffbGraphPos.append(dataTime,  streams.sensors.curForceLimitNorm); // ffb limit (from binding settings)
          maxffbGraphNeg.append(dataTime, -streams.sensors.curForceLimitNorm); // ffb limit (from binding settings)
          ffbAtDriverGraph.append(dataTime,  streams.sensors.forceAtDriverNorm); // current ffb, corrected against FFB response curve and with softlock
          ffbAtWheelGraph.append(dataTime,  streams.sensors.forceAtWheelNorm);   // current ffb
        }

        var dirty = false
        for (var key in scope.sensors) {
            if (streams.sensors[key] !== undefined && scope.sensors[key] != streams.sensors[key].toFixed(4)) {
                dirty = true
                break
            }
        }
        if (streams.electrics.steering_input !== undefined && scope.input != streams.electrics.steering_input.toFixed(4)) dirty = true

        if (dirty) {
          scope.$apply(() => {
            for (var key in scope.sensors) {
              if (streams.sensors[key] !== undefined) {
                scope.sensors[key] = streams.sensors[key].toFixed(4)
              }
            }
            if (streams.electrics.steering_input !== undefined) {
              scope.input = streams.electrics.steering_input.toFixed(4)
              scope.maxInput = steerGraph.maxValue.toFixed(4)
            }
          })
        }
      })

      scope.$on('app:resized', function (event, data) {
        canvas.width = data.width
        canvas.height = data.height
      })
    }
  }
})
