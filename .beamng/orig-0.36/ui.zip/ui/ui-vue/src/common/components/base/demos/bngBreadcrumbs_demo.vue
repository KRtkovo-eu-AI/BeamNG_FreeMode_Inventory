<template>
  <div>
    Default: <BngBreadcrumbs :items="samplePath" limit="3" blur @click="onPath" />
  </div>
  <div>
    Simple: <BngBreadcrumbs :items="samplePath" limit="3" simple blur @click="onPath" />
  </div>
</template>

<script setup>
import { BngBreadcrumbs } from "@/common/components/base"

const samplePath = [
  { label: "Lorem", items: [{ label: "Ipsum" }, { label: "Opossum" }] },
  { label: "Opossum" },
  { label: "Dolor", items: [{ label: "Sit" }, { label: "Sat" }, { label: "Soup" }] },
  { label: "Sit" },
  { label: "Amet" },
]

const onPath = item => console.log("Clicked on path", item)
</script>

<script>

// Demo Metadata
// -------------------------------------------------------
import source from "./bngBreadcrumbs_demo.vue?raw"
export default {
  source,
  title: "Display interactive breadcrumbs",
  description: `Breadcrumbs in one line with dropdowns for quick navigation`,
  propInfo: [
    {
      name: "items",
      type: "Array",
      desc: "Array of objects to show in the path",
    },
    {
      name: "limit",
      type: "Number",
      desc: "Specifies the limit of how many items are shown at once (default: 3)"
    },
    {
      name: "simple",
      type: "Boolean",
      desc: "Switch to disable arrows with dropdown menus (default: false)",
    },
    {
      name: "blur",
      type: "Boolean",
      desc: "Switch to specify if breadcrumbs should blur the background behind it (default: false)",
    },
  ],
  attrInfo: [

  ],
}

</script>
