<template>
  <div class="bng-app-binding-display-wrapper">
    <div
      class="bng-app-binding-display"
      @mouseenter="onMouseEnter"
      @mouseleave="onMouseLeave"
    >
      <!-- FIXME: pls this should not be focusable, tabindex="-1" doesnt seem to work? focus happens when you plug in a gamepad -->
      <div class="flexible-area">
        <BngButton
          v-for="(action, index) in actions"
          :key="action.action || action.label"
          :accent="ACCENTS.custom"
          @mousedown="onActionClickDown(action)"
          tabindex="-1"
          :ref="index === 0 ? 'actionButton' : undefined"
          :class="['binding-row', { 'is-faded': isFaded && !isHovered, 'is-fading-out': isFadingOut }]"
          :style="{ opacity: actionOpacity }"
        >
          <div class="label-column">
            <span v-if="action.label" class="label-text">{{ $t(action.label) }}</span>
          </div>
          <div class="divider-line"></div>
          <div class="binding-column">
            <template v-if="action.bindings">
              <BngBinding
                v-for="binding in action.bindings"
                :key="binding.device + ':' + binding.control"
                :action="action.action"
                :show-unassigned="true"
                :device="binding.device"
                :device-key="binding.control"
              />
            </template>
            <BngBinding v-else :action="action.action" :show-unassigned="true" />
          </div>
        </BngButton>
      </div>
      <BngButton
        v-for="action in constantActions"
        :accent="ACCENTS.custom"
        @mousedown="onActionClickDown(action)"
        tabindex="1"
        :class="['binding-row', { 'vehicle-specific': action.action === 'toggleShowVehicleSpecificActions' }, 'is-constant', (action.action === 'toggleShowVehicleSpecificActions' ? vehicleStatusClass : null), { 'is-faded': isFaded && !isHovered }]"
      >
        <div class="label-column">
          <span v-if="action.label" class="label-text">{{ $t(action.label) }}</span>
        </div>
        <div class="binding-column">
          <template v-if="action.bindings">
            <BngBinding
              v-for="binding in action.bindings"
              :key="binding.device + ':' + binding.control"
              :action="action.action"
              :show-unassigned="true"
              :device="binding.device"
              :device-key="binding.control"
            />
          </template>
          <BngBinding v-else :action="action.action" :show-unassigned="true" />
        </div>
      </BngButton>
    </div>
  </div>
</template>

<script setup>
import { useEvents } from '@/services/events'
import { shallowRef, ref, onMounted, onBeforeUnmount, computed, watch, nextTick } from 'vue'
import { lua } from '@/bridge'
import { BngBinding, BngButton, ACCENTS, icons } from '@/common/components/base'
import { runRaw } from "@/bridge/libs/Lua.js"
import { setFocus } from '@/services/uiNavFocus'

const events = useEvents()

const actions = shallowRef([])
const constantActions = shallowRef([])
const additionalData = shallowRef({})
const isFaded = ref(false)
const isHovered = ref(false)
const mouseDownAction = ref("")
const actionButton = ref(null)
const actionOpacity = ref(1)
let fadeOutTimeout = null
const isFadingOut = ref(false)

const setActions = data => {
  const newActions = Array.isArray(data.actions) ? data.actions : []
  constantActions.value = Array.isArray(data.constantActions) ? data.constantActions : []

  // Always update constantActions and additionalData immediately
  additionalData.value = data.additionalData ? { ...data.additionalData } : {}

  // Clear any existing fade-out timeout
  if (fadeOutTimeout) {
    clearTimeout(fadeOutTimeout)
    fadeOutTimeout = null
    isFadingOut.value = false
  }

  // If we have current actions and new actions is empty, fade out first
  if (actions.value.length > 0 && newActions.length === 0) {
    isFadingOut.value = true
    actionOpacity.value = 0 // Start fade-out
    // Wait for fade-out transition to complete (0.15s) then clear actions (animations are disabled, so the timeout is currently 0s)
    fadeOutTimeout = setTimeout(() => {
      actions.value = newActions
      actionOpacity.value = 1 // Reset opacity for next actions
      isFadingOut.value = false
      fadeOutTimeout = null
    }, 0)
  } else {
    // If we're getting new actions and previously had no actions, fade them in
    if (newActions.length > 0 && actions.value.length === 0) {
      actions.value = newActions
      // Start with 0 opacity for first-time actions, then fade in
      actionOpacity.value = 0
      // Use nextTick to ensure DOM update, then fade in
      nextTick(() => {
        actionOpacity.value = 1
      })
    } else {
      // For action changes (non-empty to non-empty) or any other case, just swap immediately
      actions.value = newActions
      actionOpacity.value = 1
    }
  }
}

// Compute class for vehicle-specific status to keep template simple
const vehicleStatusClass = computed(() => {
  switch (additionalData.value?.vehicleSpecificStatus) {
    case 'enabled':
      return 'vehicle-status-enabled'
    default:
      return 'vehicle-status-default'
  }
})

const onActionClickDown = (action) => {
  if (action.onClick) {
    runRaw(action.onClick)
  } else if (action.inputActionOnClick) {
    mouseDownAction.value = action.action
    lua.ui_bindingsLegend.triggerInputAction(action.action, 1)
  }
}

const onMouseEnter = () => { isHovered.value = true }
const onMouseLeave = () => { isHovered.value = false }

const onGlobalMouseUp = (event) => {
  if (mouseDownAction.value) {
    lua.ui_bindingsLegend.triggerInputAction(mouseDownAction.value, 0)
    mouseDownAction.value = ""
  }
}

// Watch for changes to vehicle specific status and focus button when enabled
watch(() => additionalData.value?.vehicleSpecificStatus, async (newStatus) => {
  if (actionButton.value && newStatus === 'enabled') {
    await nextTick()
    setFocus(actionButton.value.$el, true)
  }
})

onMounted(() => {
  events.on("setActionsForLegend", setActions)
  events.on("setBindingsLegendFade", (value) => { isFaded.value = !!value })
  lua.ui_bindingsLegend.sendDataToUI()

  document.addEventListener('mouseup', onGlobalMouseUp)
})

onBeforeUnmount(() => {
  document.removeEventListener('mouseup', onGlobalMouseUp)
  // Clear any pending fade-out timeout
  if (fadeOutTimeout) {
    clearTimeout(fadeOutTimeout)
    fadeOutTimeout = null
  }
  // Reset opacity state
  actionOpacity.value = 1
})

</script>

<style lang="scss" scoped>
.bng-app-binding-display-wrapper {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  height: 100%;
  justify-content: flex-end;
  color: var(--bng-off-white-brighter);
  align-items: stretch;

  .bng-app-binding-display {
    display: flex;
    flex-direction: column;
    overflow-x: hidden;
    overflow-y: auto;

    &::-webkit-scrollbar { // Chromium/CEF
      width: 0.125em;
      height: 0.125em;
    }

    padding: 0.125em;

    // Smoothly animate background opacity changes for rows
    .binding-row :deep(.background) { transition: opacity 0.25s ease-in-out;
    }

    .flexible-area {
      flex: 1 1 auto;
      display: flex;
      flex-direction: column;
      overflow: hidden auto;
      &::-webkit-scrollbar { // Chromium/CEF
        width: 4px;
        height: 4px;
      }
      // padding: 0 0.125em;
      // .binding-row {
      //   margin: 0 -0.125em;
      // }
    }

    .binding-row {
      //box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.25);
      // border-bottom: 1px solid rgba(var(--bng-cool-gray-400-rgb), 0.5);
      max-width: unset;
      justify-content: space-between;
      font-size: 1em;
      flex-direction: row;
      padding: 0.125em 0.25em 0.125em 0.25em;
      margin: 0;
      display: flex;
      border-radius: 0;
      align-items: flex-start;
      text-shadow: 0 0 4px rgba(var(--bng-off-black-rgb), 0.15);
      transform-origin: center;
      flex: 0 0 auto;

      --bng-color-text: var(--bng-off-white-brighter);

      /* Preserve previous accent="text" visuals while using accent="custom" */
      --bng-button-custom-margin: 0;
      --bng-button-custom-border-radius: 0 0 0 0;
      --bng-button-custom-enabled: var(--bng-cool-gray-850);
      --bng-button-custom-enabled-opacity: 0.4;
      --bng-button-custom-hover: var(--bng-orange-400);
      --bng-button-custom-hover-opacity: 1;
      --bng-button-custom-active: var(--bng-cool-gray-850);
      --bng-button-custom-active-opacity: 1;
      --bng-button-custom-disabled: var(--bng-cool-gray-850);
      --bng-button-custom-disabled-opacity: 0.4;

      &:focus,
      // &:focus-visible,
      &.focus-visible {
        &::before {
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
          border-radius: 0.125em;
        }
      }

      // Alternating background colors for buttons (counting from bottom)
      &:nth-last-child(odd) {
        --bng-button-custom-enabled-opacity: 0.4;
      }

      &:nth-last-child(even) {
        --bng-button-custom-enabled-opacity: 0.5;
      }

      // Make constant actions more transparent
      &.is-constant {
        --bng-button-custom-enabled-opacity: 0.25;
      }

      .divider-line {
        flex: 1 1 auto;
        height: 1px;
        background-color: var(--bng-cool-gray-850);
        opacity: 0;
        margin-top: 0.75em;
        margin-right: 0.25em;
      }

      :deep(.background) {
        border-radius: 0;
      }
      .label-column {
        flex: 0 1 auto;
        max-width: 55%;
        text-align: left;
        display: flex;
        align-items: flex-start;
        color: var(--bng-off-white-brighter);
        line-height: 1.25em;
        min-height: 1.75em;
        padding-top: 0.125em;
        .label-text {
          display: inline-block;
          padding-bottom: 0.125em;
          padding-left: 0.25em;
          padding-right: 0.25em;
          border-radius: 0.125em;
        }
      }
      &.is-faded {
        --bng-button-custom-enabled-opacity: 0.02;
        --bng-button-custom-disabled-opacity: 0.02;
        text-shadow: 0 0 4px rgba(var(--bng-off-black-rgb), 0.1);
        .divider-line {
          opacity: 0.075;
        }
        .label-column {
          .label-text {
            background: rgba(var(--bng-cool-gray-850-rgb), 0.15);
          }
        }
        .binding-column {
          :deep(.bng-binding-icon) {
            background: radial-gradient(circle at 50% 50%, rgba(var(--bng-cool-gray-850-rgb), 0.2) 0%, rgba(var(--bng-cool-gray-850-rgb), 0) 175%);
            border-radius: 0.125em;
          }
        }
      }


      .binding-column {
        display: flex;
        flex-flow: row wrap;
        align-items: center;
        justify-content: flex-end;
        min-height: 1.75em;
        gap: 0.125em;
        flex: 0 1 auto;
        max-width: 40%;
      }

        // Vehicle-specific row styling
        &.vehicle-specific {
          // Label color based on status
          &.vehicle-status-enabled {
            --bng-icon-color: var(--bng-orange-300);
            --bng-button-custom-enabled: var(--bng-cool-gray-800);
            --bng-button-custom-enabled-opacity: 1;
            --bng-button-custom-border-enabled: var(--bng-cool-gray-700);
            .label-column {
              color: var(--bng-orange-300);
              font-weight: 600;
            }
          }

          &.vehicle-status-default {
            --bng-icon-color: var(--bng-off-white-brighter);
            .label-column { color: var(--bng-off-white-brighter); }
          }

          &.vehicle-status-inactive {
            --bng-icon-color: var(--bng-cool-gray-100);
            .label-column { color: var(--bng-cool-gray-100); }
          }
        }
    }

    .modifier-binding {
      display: inline-block;

      &.active {
        background-color: var(--bng-orange-b400);
        transform: scale(1.1);
      }
    }
  }
}
</style>
