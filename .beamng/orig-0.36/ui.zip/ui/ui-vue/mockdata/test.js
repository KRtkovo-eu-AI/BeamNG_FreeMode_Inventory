export default {

	myValue: 444
	
}