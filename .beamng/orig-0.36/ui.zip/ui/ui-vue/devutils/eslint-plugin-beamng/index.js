module.exports = {
  rules: {
    "vue-template-operators": require("./rules/vue-template-operators")
  }
};
